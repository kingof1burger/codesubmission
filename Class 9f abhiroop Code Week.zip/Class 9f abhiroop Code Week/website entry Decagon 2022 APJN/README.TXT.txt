Decagon entry from Apeejay school, Noida, Group 1 (HTML & CSS ONLY)

Good day to you judges! This is the entry of apeejay school noida for group 1 by Abhiroop kapoor and Vippul Mittal
We have used 6 html files and one css files as code, and 28 images as dependencies. Attached you will also find some 
images showcasing big text areas and some other areas of the website, we have also prepared a 2 minute video 
showcasing everything the website has to offer!

In our entry, we have decided to use DC as our choice of e-commerce website.
Introducing Tradeforce! the website supplies superpowered weapons and famous tools used by villians and heroes to 
people from even different universes! learn more through the About page.

The main page showcases a carousel with different heroes and villains, directing you to the products page. Below that
there is a gallery of links showcasing some offers and collections ongoing in the website. Below that you will find 
a short point by point of the website's function and how to use it, after which you can find two testimonials by much
loved hero Green Arrow and supervillain doomsday!

The navbar moves with your window, and the footer has a 3 line description of Tradeforce, with some hyperlinks.
(try the hyperlinks for a surprise)

than comes our about page, self explanatory.

after which comes the products page, showcasing 16 frequent bought accessories. Hover over the images for adding them
to cart and buying them (Note: this function is just for redirecting to the products page, as without javascript i 
couldn't find out how to add the items in the cart)

Than comes the Contact page, this is where one can ask for offers, and request orders, and other such FAQs.
Dont worry the Tradeforce isnt affected by the number of requests, afterall it is the biggest network of commerce!.

Than comes the cart, this is just a showcase page, because sadly i couldn't figure out how to use css and html for 
adding and removing items from cart, or increasing and decreasing amount etc.

Hope you enjoy the website's look! (If you give us the win there is a free cookie in it for you)

From,
Team Apeejay Noida

